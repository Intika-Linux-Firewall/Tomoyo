/*
 * security/tomoyo/realpath.h
 *
 * Get the canonicalized absolute pathnames. The basis for TOMOYO.
 *
 * Copyright (C) 2005-2008  NTT DATA CORPORATION
 *
 * Version: 2.2.0-pre   2008/04/30
 *
 */

#ifndef _LINUX_REALPATH_H
#define _LINUX_REALPATH_H

struct dentry;
struct vfsmount;
struct condition_list;
struct path_info;

/* Returns realpath(3) of the given pathname but ignores chroot'ed root. */
int tmy_realpath_from_dentry2(struct dentry *dentry, struct vfsmount *mnt,
			      char *newname, int newname_len);

/*
 * Returns realpath(3) of the given pathname but ignores chroot'ed root.
 * These functions use tmy_alloc(), so caller must tmy_free()
 * if these functions didn't return NULL.
 */
char *tmy_realpath(const char *pathname);
/* Same with tmy_realpath() except that it doesn't follow the final symlink. */
char *tmy_realpath_nofollow(const char *pathname);
/* Same with tmy_realpath() except that the pathname is already solved. */
char *tmy_realpath_from_dentry(struct dentry *dentry, struct vfsmount *mnt);

/*
 * Allocate memory for ACL entry.
 * The RAM is chunked, so NEVER try to kfree() the returned pointer.
 */
void *tmy_alloc_element(const unsigned int size);

/* Get used RAM size for tmy_alloc_elements(). */
unsigned int tmy_get_memory_used_for_elements(void);

/*
 * Keep the given name on the RAM.
 * The RAM is shared, so NEVER try to modify or kfree() the returned name.
 */
const struct path_info *tmy_save_name(const char *name);

/* Get used RAM size for tmy_save_name(). */
unsigned int tmy_get_memory_used_for_save_name(void);

/* Allocate memory for temporary use (e.g. permission checks). */
void *tmy_alloc(const size_t size);

/* Get used RAM size for tmy_alloc(). */
unsigned int tmy_get_memory_used_for_dynamic(void);

/* Free memory allocated by tmy_alloc(). */
void tmy_free(const void *p);

#endif
