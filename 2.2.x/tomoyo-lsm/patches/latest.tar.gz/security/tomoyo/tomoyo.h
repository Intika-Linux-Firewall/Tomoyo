/*
 * security/tomoyo/tomoyo.h
 *
 * Implementation of the Domain-Based Mandatory Access Control.
 *
 * Copyright (C) 2005-2008  NTT DATA CORPORATION
 *
 * Version: 2.2.0-pre   2008/04/30
 *
 */

#ifndef _LINUX_TOMOYO_H
#define _LINUX_TOMOYO_H

struct path_info;
struct dentry;
struct vfsmount;
struct inode;
struct linux_binprm;
struct pt_regs;
struct tmy_page_buffer;

char *sysctlpath_from_table(struct ctl_table *table);
int tmy_check_file_perm(const char *filename, const u8 perm,
			const char *operation);
int tmy_check_exec_perm(const struct path_info *filename,
			struct tmy_page_buffer *buf);
int tmy_check_open_permission(struct dentry *dentry, struct vfsmount *mnt,
			      const int flag);
int tmy_check_1path_perm(const u8 operation,
			 struct dentry *dentry,
			 struct vfsmount *mnt);
int tmy_check_2path_perm(const u8 operation,
			 struct dentry *dentry1,
			 struct vfsmount *mnt1,
			 struct dentry *dentry2,
			 struct vfsmount *mnt2);
int tmy_check_rewrite_permission(struct file *filp);
int tmy_find_next_domain(struct linux_binprm *bprm,
			 struct domain_info **next_domain);

#define TMY_CHECK_READ_FOR_OPEN_EXEC 1

/* Index numbers for Access Controls. */

#define TYPE_SINGLE_PATH_ACL                 0
#define TYPE_DOUBLE_PATH_ACL                 1

/* Index numbers for File Controls. */

/*
 * TYPE_READ_WRITE_ACL is special. TYPE_READ_WRITE_ACL is automatically set
 * if both TYPE_READ_ACL and TYPE_WRITE_ACL are set. Both TYPE_READ_ACL and
 * TYPE_WRITE_ACL are automatically set if TYPE_READ_WRITE_ACL is set.
 * TYPE_READ_WRITE_ACL is automatically cleared if either TYPE_READ_ACL or
 * TYPE_WRITE_ACL is cleared. Both TYPE_READ_ACL and TYPE_WRITE_ACL are
 * automatically cleared if TYPE_READ_WRITE_ACL is cleared.
 */

#define TMY_TYPE_READ_WRITE_ACL        0
#define TMY_TYPE_EXECUTE_ACL           1
#define TMY_TYPE_READ_ACL              2
#define TMY_TYPE_WRITE_ACL             3
#define TMY_TYPE_CREATE_ACL            4
#define TMY_TYPE_UNLINK_ACL            5
#define TMY_TYPE_MKDIR_ACL             6
#define TMY_TYPE_RMDIR_ACL             7
#define TMY_TYPE_MKFIFO_ACL            8
#define TMY_TYPE_MKSOCK_ACL            9
#define TMY_TYPE_MKBLOCK_ACL          10
#define TMY_TYPE_MKCHAR_ACL           11
#define TMY_TYPE_TRUNCATE_ACL         12
#define TMY_TYPE_SYMLINK_ACL          13
#define TMY_TYPE_REWRITE_ACL          14
#define MAX_SINGLE_PATH_OPERATION 15

#define TMY_TYPE_LINK_ACL             0
#define TMY_TYPE_RENAME_ACL           1
#define MAX_DOUBLE_PATH_OPERATION 2

struct tmy_security {
	struct domain_info *domain;
	struct domain_info *prev_domain;
	u32 flags;
};

#define TMY_SECURITY ((struct tmy_security *) current->security)

#define TMY_DOMAINPOLICY          0
#define TMY_EXCEPTIONPOLICY       1
#define TMY_DOMAIN_STATUS         2
#define TMY_PROCESS_STATUS        3
#define TMY_MEMINFO               4
#define TMY_SELFDOMAIN            5
#define TMY_VERSION               6
#define TMY_PROFILE               7
#define TMY_MANAGER               8
#define TMY_UPDATESCOUNTER        9

extern struct domain_info KERNEL_DOMAIN;

#endif
