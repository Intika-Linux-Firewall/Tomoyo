/*
 * security/tomoyo/tomoyo.c
 *
 * LSM hooks for TOMOYO Linux.
 */

#include <linux/security.h>
#include "common.h"
#include "tomoyo.h"
#include "realpath.h"

static struct kmem_cache *tmy_cachep;

static int tmy_task_alloc_security(struct task_struct *p)
{
	struct tmy_security *ptr = kmem_cache_alloc(tmy_cachep, GFP_KERNEL);

	if (!ptr)
		return -ENOMEM;
	memcpy(ptr, TMY_SECURITY, sizeof(*ptr));
	p->security = ptr;
	return 0;
}

static void tmy_task_free_security(struct task_struct *p)
{
	kmem_cache_free(tmy_cachep, p->security);
}

static int tmy_bprm_alloc_security(struct linux_binprm *bprm)
{
	TMY_SECURITY->prev_domain = TMY_SECURITY->domain;
	return 0;
}

static int tmy_bprm_check_security(struct linux_binprm *bprm)
{
	struct domain_info *next_domain = NULL;
	int retval = 0;

	tmy_load_policy(bprm->filename);

	/*
	 * TMY_CHECK_READ_FOR_OPEN_EXEC bit indicates whether this function is
	 * called by do_execve() or not.
	 * If called by do_execve(), I do domain transition.
	 */
	if ((TMY_SECURITY->flags & TMY_CHECK_READ_FOR_OPEN_EXEC))
		goto out;
	retval = tmy_find_next_domain(bprm, &next_domain);
	if (retval)
		goto out;
	TMY_SECURITY->domain = next_domain;
	TMY_SECURITY->flags |= TMY_CHECK_READ_FOR_OPEN_EXEC;
out:
	return retval;
}

static void tmy_bprm_post_apply_creds(struct linux_binprm *bprm)
{
	TMY_SECURITY->prev_domain = TMY_SECURITY->domain;
}

static void tmy_bprm_free_security(struct linux_binprm *bprm)
{
	TMY_SECURITY->domain = TMY_SECURITY->prev_domain;
	TMY_SECURITY->flags &= ~TMY_CHECK_READ_FOR_OPEN_EXEC;
}

static int tmy_sysctl(struct ctl_table *table, int op)
{
	int error;
	char *name;

	if ((op & 6) == 0)
		return 0;

	name = sysctlpath_from_table(table);
	if (!name)
		return -ENOMEM;

	error = tmy_check_file_perm(name, op & 6, "sysctl");
	tmy_free(name);

	return error;
}

static int tmy_path_truncate(struct path *path, loff_t length,
			     unsigned int time_attrs, struct file *filp)
{
	return tmy_check_1path_perm(TMY_TYPE_TRUNCATE_ACL, path->dentry,
				    path->mnt);
}

static inline int pre_vfs_create(struct inode *dir, struct dentry *dentry,
				 struct nameidata *nd)
{
	int error = may_create(dir, dentry, nd);

	if (error)
		return error;

	if (!dir->i_op || !dir->i_op->create)
		return -EACCES;	/* shouldn't it be ENOSYS? */
	return 0;
}

static int tmy_path_create(struct path *dir, struct dentry *dentry, int mode,
			   struct nameidata *nd)
{
	int error;

	if (!nd || !nd->path.mnt)
		return 0;
	error = pre_vfs_create(dir->dentry->d_inode, dentry, nd);
	if (error)
		return error;
	return tmy_check_1path_perm(TMY_TYPE_CREATE_ACL, dentry, nd->path.mnt);
}

static inline int pre_vfs_unlink(struct inode *dir, struct dentry *dentry)
{
	int error = may_delete(dir, dentry, 0);

	if (error)
		return error;

	if (!dir->i_op || !dir->i_op->unlink)
		return -EPERM;
	return 0;
}

static int tmy_path_unlink(struct path *dir, struct dentry *dentry)
{
	const int err = pre_vfs_unlink(dir->dentry->d_inode, dentry);
	if (err)
		return err;
	return tmy_check_1path_perm(TMY_TYPE_UNLINK_ACL, dentry, dir->mnt);
}

static inline int pre_vfs_mkdir(struct inode *dir, struct dentry *dentry)
{
	int error = may_create(dir, dentry, NULL);

	if (error)
		return error;

	if (!dir->i_op || !dir->i_op->mkdir)
		return -EPERM;
	return 0;
}

static int tmy_path_mkdir(struct path *dir, struct dentry *dentry, int mode)
{
	const int err = pre_vfs_mkdir(dir->dentry->d_inode, dentry);
	if (err)
		return err;
	return tmy_check_1path_perm(TMY_TYPE_MKDIR_ACL, dentry, dir->mnt);
}

static inline int pre_vfs_rmdir(struct inode *dir, struct dentry *dentry)
{
	int error = may_delete(dir, dentry, 1);

	if (error)
		return error;

	if (!dir->i_op || !dir->i_op->rmdir)
		return -EPERM;
	return 0;
}

static int tmy_path_rmdir(struct path *dir, struct dentry *dentry)
{
	const int err = pre_vfs_rmdir(dir->dentry->d_inode, dentry);
	if (err)
		return err;
	return tmy_check_1path_perm(TMY_TYPE_RMDIR_ACL, dentry, dir->mnt);
}

static inline int pre_vfs_symlink(struct inode *dir, struct dentry *dentry)
{
	int error = may_create(dir, dentry, NULL);

	if (error)
		return error;

	if (!dir->i_op || !dir->i_op->symlink)
		return -EPERM;
	return 0;
}

static int tmy_path_symlink(struct path *dir, struct dentry *dentry,
			    const char *old_name)
{
	const int err = pre_vfs_symlink(dir->dentry->d_inode, dentry);
	if (err)
		return err;
	return tmy_check_1path_perm(TMY_TYPE_SYMLINK_ACL, dentry, dir->mnt);
}

static inline int pre_vfs_mknod(struct inode *dir, struct dentry *dentry,
				int mode)
{
	int error = may_create(dir, dentry, NULL);

	if (error)
		return error;

	if ((S_ISCHR(mode) || S_ISBLK(mode)) && !capable(CAP_MKNOD))
		return -EPERM;

	if (!dir->i_op || !dir->i_op->mknod)
		return -EPERM;
	return 0;
}

static int tmy_path_mknod(struct path *dir, struct dentry *dentry, int mode,
			  unsigned int dev)
{
	struct vfsmount *mnt = dir->mnt;
	int err = 0;
	switch (mode & S_IFMT) {
	case S_IFCHR:
	case S_IFBLK:
	case S_IFIFO:
	case S_IFSOCK:
		break;
	default:
		return 0;
	}
	err = pre_vfs_mknod(dir->dentry->d_inode, dentry, mode);
	if (err)
		return err;
	if (S_ISCHR(mode))
		return tmy_check_1path_perm(TMY_TYPE_MKCHAR_ACL, dentry, mnt);
	if (S_ISBLK(mode))
		return tmy_check_1path_perm(TMY_TYPE_MKBLOCK_ACL, dentry, mnt);
	if (S_ISFIFO(mode))
		return tmy_check_1path_perm(TMY_TYPE_MKFIFO_ACL, dentry, mnt);
	if (S_ISSOCK(mode))
		return tmy_check_1path_perm(TMY_TYPE_MKSOCK_ACL, dentry, mnt);
	return 0;
}

static inline int pre_vfs_link(struct dentry *old_dentry, struct inode *dir,
			       struct dentry *new_dentry)
{
	struct inode *inode = old_dentry->d_inode;
	int error;

	if (!inode)
		return -ENOENT;

	error = may_create(dir, new_dentry, NULL);
	if (error)
		return error;

	if (dir->i_sb != inode->i_sb)
		return -EXDEV;

	/*
	 * A link to an append-only or immutable file cannot be created.
	 */
	if (IS_APPEND(inode) || IS_IMMUTABLE(inode))
		return -EPERM;
	if (!dir->i_op || !dir->i_op->link)
		return -EPERM;
	if (S_ISDIR(old_dentry->d_inode->i_mode))
		return -EPERM;
	return 0;
}

static inline int pre_vfs_rename(struct inode *old_dir,
				 struct dentry *old_dentry,
				 struct inode *new_dir,
				 struct dentry *new_dentry)
{
	int error;
	int is_dir = S_ISDIR(old_dentry->d_inode->i_mode);

	if (old_dentry->d_inode == new_dentry->d_inode)
		return 0;

	error = may_delete(old_dir, old_dentry, is_dir);
	if (error)
		return error;

	if (!new_dentry->d_inode)
		error = may_create(new_dir, new_dentry, NULL);
	else
		error = may_delete(new_dir, new_dentry, is_dir);
	if (error)
		return error;

	if (!old_dir->i_op || !old_dir->i_op->rename)
		return -EPERM;
	return 0;
}

static int tmy_path_link(struct path *old_path, struct path *new_dir,
			 struct dentry *new_dentry)
{
	const int err = pre_vfs_link(old_path->dentry, new_dir->dentry->d_inode,
				     new_dentry);
	if (err)
		return err;
	return tmy_check_2path_perm(TMY_TYPE_LINK_ACL,
				    old_path->dentry, old_path->mnt,
				    new_dentry, new_dir->mnt);
}

static int tmy_path_rename(struct path *old_dir, struct dentry *old_dentry,
			   struct path *new_dir, struct dentry *new_dentry)
{
	const int err = pre_vfs_rename(old_dir->dentry->d_inode, old_dentry,
				       new_dir->dentry->d_inode, new_dentry);
	if (err)
		return err;
	return tmy_check_2path_perm(TMY_TYPE_RENAME_ACL,
				    old_dentry, old_dir->mnt,
				    new_dentry, new_dir->mnt);
}

static int tmy_file_fcntl(struct file *file, unsigned int cmd,
			  unsigned long arg)
{
	if (cmd == F_SETFL && ((arg ^ file->f_flags) & O_APPEND))
		return tmy_check_rewrite_permission(file);
	return 0;
}

static int tmy_dentry_open(struct file *f)
{
	int flags = f->f_flags;
	if ((flags + 1) & O_ACCMODE)
		flags++;
	return tmy_check_open_permission(f->f_dentry, f->f_vfsmnt,
					 flags | (f->f_flags & (O_APPEND | O_TRUNC)));
}

static struct security_operations tomoyo_security_ops = {
	.name                      = "tomoyo",

	.task_alloc_security       = tmy_task_alloc_security,
	.task_free_security        = tmy_task_free_security,
	.bprm_alloc_security       = tmy_bprm_alloc_security,
	.bprm_check_security       = tmy_bprm_check_security,
	.bprm_post_apply_creds     = tmy_bprm_post_apply_creds,
	.bprm_free_security        = tmy_bprm_free_security,
	.sysctl                    = tmy_sysctl,
	.file_fcntl                = tmy_file_fcntl,
	.dentry_open               = tmy_dentry_open,

	.path_truncate             = tmy_path_truncate,
	.path_create               = tmy_path_create,
	.path_unlink               = tmy_path_unlink,
	.path_mkdir                = tmy_path_mkdir,
	.path_rmdir                = tmy_path_rmdir,
	.path_symlink              = tmy_path_symlink,
	.path_mknod                = tmy_path_mknod,
	.path_link                 = tmy_path_link,
	.path_rename               = tmy_path_rename,
};

static int __init tmy_init(void)
{
	struct tmy_security *tmy_security;
	if (!security_module_enable(&tomoyo_security_ops))
		return 0;

	/* register ourselves with the security framework */
	if (register_security(&tomoyo_security_ops))
		panic("Failure registering TOMOYO Linux");

	printk(KERN_INFO "TOMOYO Linux initialized\n");
	tmy_cachep = kmem_cache_create("tomoyo_security",
				       sizeof(struct tmy_security),
				       0, SLAB_PANIC, NULL);
	tmy_security = kmem_cache_alloc(tmy_cachep, GFP_KERNEL);
	BUG_ON(!tmy_security);
	memset(tmy_security, 0, sizeof(*tmy_security));
	tmy_security->domain = &KERNEL_DOMAIN;
	init_task.security = tmy_security;
	return 0;
}

security_initcall(tmy_init);
