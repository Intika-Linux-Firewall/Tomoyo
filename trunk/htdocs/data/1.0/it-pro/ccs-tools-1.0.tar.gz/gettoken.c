/*
 * gettoken.c
 *
 * An example program for CERBERUS.
 *
 * Copyright (C) 2005  NTT DATA Corporation
 *
 * Version: 1.0 2005/11/11
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[]) {
	static char seed[40];
	int i;
	srand(time(NULL) / 30);
	memset(seed, 0, sizeof(seed));
	for (i = 0; i < sizeof(seed) - 1; i++) seed[i] = (rand() % 64) + 33;
	printf("%s\n", seed);
	return 0;
}
